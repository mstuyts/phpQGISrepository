# -*- coding: utf-8 -*-
"""
/***************************************************************************
 ExamplePluginDialog
                                 A QGIS plugin
 An example plugin shipped with phpQGISrepository
                             -------------------
        begin                : 2016-03-08
        git sha              : $Format:%H$
        copyright            : (C) 2016 by Michel Stuyts
        email                : michel@stuyts.xyz
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""

import os
try:
    from qgis.PyQt.QtCore import *
except ImportError:
    from PyQt4.QtCore import *
try:
    from qgis.PyQt.QtGui import QIcon
    from qgis.PyQt.QtWidgets import QDialog
except ImportError:
    from PyQt4.QtGui import QIcon, QDialog
try:
    from PyQt4 import uic
except ImportError:
    from PyQt5 import uic

FORM_CLASS, _ = uic.loadUiType(os.path.join(
    os.path.dirname(__file__), 'example_plugin_dialog_base.ui'))


class ExamplePluginDialog(QDialog, FORM_CLASS):
    def __init__(self, parent=None):
        """Constructor."""
        super(ExamplePluginDialog, self).__init__(parent)
        self.setWindowIcon(QIcon(":/plugins/ExamplePlugin/icon.png"))
        self.setWindowFlags( self.windowFlags() & ~Qt.WindowContextHelpButtonHint )
        self.setupUi(self)
